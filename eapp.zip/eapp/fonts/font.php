<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,300;0,400;0,500;1,700&family=Plus+Jakarta+Sans:wght@600&family=Tilt+Neon&display=swap" rel="stylesheet">

<style>
    body{
 
font-family: 'Tilt Neon', sans-serif;
    }
</style>