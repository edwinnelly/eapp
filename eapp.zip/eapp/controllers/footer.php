<footer class="footer text-center text-muted">
                All Rights Reserved by Yelocodesystems. Designed and Developed by <a
                    href="https://yelocodesystems.com">Yelocode Systems</a>.
            </footer>